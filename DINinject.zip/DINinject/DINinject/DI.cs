﻿using Ninject.Modules;
using Models;


namespace DINinject
{
    public class DI : NinjectModule
    {
        /// <summary>
        /// Registration of the interface and class into the Ninject cointainer.
        /// </summary>
        public override void Load()
        {
            Bind<IGameCompany>().To<DeveloperCompany>();
            Bind<IGameCompany>().To<PublisherCompany>();
        }
    }
}
