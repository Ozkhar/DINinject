﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ninject;
using System.Reflection;
using Models;
using Factory;


namespace DINinject
{
    /// <summary>
    /// With the injection of the interface object, "DeveloperCompany" and "DeveloperCompany" are decoupled from the
    /// this class. The one who has "GetCompanyDetails()"
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());

            //Gets all the objects registered in the Load() method of the DI class
            IEnumerable<IGameCompany> companies = kernel.GetAll<IGameCompany>();

            foreach (IGameCompany company in companies)
            {
                //Object "company" is injected into the GameCompany constructor
                var gameCompany = new GameCompany(company);
                gameCompany.GetCompanyDetails();           
            }
            Console.ReadLine();
        }
    }
}
