﻿using System;

namespace Models
{
    public class DeveloperCompany : IGameCompany
    {
        public void GetDetails()
        {
            Console.WriteLine("Developer Company");
        }
    }
}
