﻿namespace Models
{
    public interface IGameCompany
    {
        void GetDetails();
    }
}
