﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Factory
{
    public class GameCompany
    {
        private readonly IGameCompany cust;

        /// <summary>
        /// Injection Happens here. Custom Inversion of Control object is passed in to the Constructor.
        /// </summary>
        /// <param name="custIOC">Inversion od Control</param>        
        public GameCompany(IGameCompany custIOC)
        {
            cust = custIOC;
        }

        public void GetCompanyDetails()
        {
            cust.GetDetails();
        }
    }
}
